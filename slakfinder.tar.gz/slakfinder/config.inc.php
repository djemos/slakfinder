<?php

/* Use this file to override default settings */
/* See inc/config_defs.inc.php for details */

/* You MUST modify at least these parameters */

$dbhost = 'localhost';
$dbuser = 'root';
$dbpass = 'djemos';
$dbdata = 'slakdb';
$dbpref = 'spf_';
